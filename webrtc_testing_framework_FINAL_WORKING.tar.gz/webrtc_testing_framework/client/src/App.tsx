import React, { useState, useEffect, useRef } from 'react';
import './App.css';
import { WebRTCService, ArchitectureMode } from './services/WebRTCService';

function App() {
  const [mode, setMode] = useState<ArchitectureMode>('P2P');
  const [role, setRole] = useState<'presenter' | 'viewer'>('viewer');
  const [roomId, setRoomId] = useState('test-room');
  const [isConnected, setIsConnected] = useState(false);
  const [webrtcService, setWebrtcService] = useState<WebRTCService | null>(null);
  const [latencyHistory, setLatencyHistory] = useState<number[]>([]);

  // Expose state globally for automation scripts
  useEffect(() => {
    (window as any).isConnected = isConnected;
    (window as any).webrtcService = webrtcService;
  }, [isConnected, webrtcService]);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRefs = useRef<Map<string, HTMLVideoElement>>(new Map());
  const remoteVideosContainerRef = useRef<HTMLDivElement>(null);

  // Get configuration from URL parameters or environment
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlMode = params.get('mode') as ArchitectureMode;
    const urlRole = params.get('role') as 'presenter' | 'viewer';
    const urlRoomId = params.get('roomId');

    if (urlMode) setMode(urlMode);
    if (urlRole) setRole(urlRole);
    if (urlRoomId) setRoomId(urlRoomId);
  }, []);

  // Calculate latency for viewer role
  useEffect(() => {
    if (role === 'viewer' && isConnected) {
      const interval = setInterval(() => {
        remoteVideoRefs.current.forEach((video) => {
          if (video && webrtcService) {
            const extractedTimestamp = webrtcService.extractTimestamp(video);
            if (extractedTimestamp) {
              const currentTime = Date.now();
              const latency = currentTime - extractedTimestamp;
              if (latency > 0 && latency < 10000) { // Reasonable latency bounds
                setLatencyHistory(prev => [...prev.slice(-99), latency]); // Keep last 100 measurements
              }
            }
          }
        });
      }, 1000); // Measure every second

      return () => clearInterval(interval);
    }
  }, [role, isConnected, webrtcService]);

  const handleConnect = async () => {
    try {
      const signalingServerUrl = process.env.REACT_APP_SIGNALING_URL || 'http://localhost:3001';
      const sfuServerUrl = process.env.REACT_APP_SFU_URL || 'http://localhost:3002';
      
      console.log('Environment variables:', {
        REACT_APP_SIGNALING_URL: process.env.REACT_APP_SIGNALING_URL,
        REACT_APP_SFU_URL: process.env.REACT_APP_SFU_URL,
        signalingServerUrl,
        sfuServerUrl
      });

      const service = new WebRTCService({
        mode,
        signalingServerUrl,
        sfuServerUrl: mode === 'SFU' ? sfuServerUrl : undefined,
        role,
        roomId
      });

      // Set up connection handler
      service.setOnConnectedCallback(() => {
        console.log('WebRTC service connected');
        setIsConnected(true);
      });

      // Set up stream handlers
      service.setOnLocalStreamCallback((stream) => {
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      });

      service.setOnRemoteStreamCallback((stream, peerId) => {
        // Create or update remote video element
        let video = remoteVideoRefs.current.get(peerId);
        if (!video) {
          video = document.createElement('video');
          video.autoplay = true;
          video.playsInline = true;
          video.style.width = '300px';
          video.style.height = '200px';
          video.style.border = '1px solid #ccc';
          video.style.margin = '10px';
          
          remoteVideoRefs.current.set(peerId, video);
          remoteVideosContainerRef.current?.appendChild(video);
        }
        video.srcObject = stream;
      });

      await service.initialize();
      setWebrtcService(service);
      
      // Only set connected after socket connection is established
      // This will be set to true by the socket connection handler
    } catch (error) {
      console.error('Connection failed:', error);
      alert('Failed to connect: ' + error);
    }
  };

  const handleDisconnect = async () => {
    if (webrtcService) {
      await webrtcService.disconnect();
      setWebrtcService(null);
    }
    setIsConnected(false);
    
    // Clear remote videos
    remoteVideoRefs.current.clear();
    if (remoteVideosContainerRef.current) {
      remoteVideosContainerRef.current.innerHTML = '';
    }
  };

  const averageLatency = latencyHistory.length > 0 
    ? latencyHistory.reduce((a, b) => a + b, 0) / latencyHistory.length 
    : 0;

  return (
    <div className="App">
      <header className="App-header">
        <h1>WebRTC Testing Framework</h1>
        
        <div style={{ marginBottom: '20px' }}>
          <div>
            <label>Architecture: </label>
            <select value={mode} onChange={(e) => setMode(e.target.value as ArchitectureMode)} disabled={isConnected}>
              <option value="P2P">P2P Mesh</option>
              <option value="SFU">SFU</option>
            </select>
          </div>
          
          <div>
            <label>Role: </label>
            <select value={role} onChange={(e) => setRole(e.target.value as 'presenter' | 'viewer')} disabled={isConnected}>
              <option value="presenter">Presenter</option>
              <option value="viewer">Viewer</option>
            </select>
          </div>
          
          <div>
            <label>Room ID: </label>
            <input 
              type="text" 
              value={roomId} 
              onChange={(e) => setRoomId(e.target.value)}
              disabled={isConnected}
            />
          </div>
        </div>

        <div>
          {!isConnected ? (
            <button onClick={handleConnect}>Connect</button>
          ) : (
            <button onClick={handleDisconnect}>Disconnect</button>
          )}
        </div>

        {role === 'viewer' && latencyHistory.length > 0 && (
          <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#333', borderRadius: '5px' }}>
            <h3>Latency Stats</h3>
            <p>Average G2G Latency: {averageLatency.toFixed(2)}ms</p>
            <p>Latest: {latencyHistory[latencyHistory.length - 1]?.toFixed(2)}ms</p>
            <p>Samples: {latencyHistory.length}</p>
          </div>
        )}

        <div style={{ marginTop: '20px' }}>
          {role === 'presenter' && (
            <div>
              <h3>Local Stream (Presenter)</h3>
              <video 
                ref={localVideoRef}
                autoPlay 
                playsInline 
                muted
                style={{ width: '400px', height: '300px', border: '2px solid #61dafb' }}
              />
            </div>
          )}

          {role === 'viewer' && (
            <div>
              <h3>Remote Streams (Viewer)</h3>
              <div ref={remoteVideosContainerRef} style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
                {/* Remote videos will be dynamically added here */}
              </div>
            </div>
          )}
        </div>

        <div style={{ marginTop: '20px', fontSize: '12px', color: '#888' }}>
          <p>Mode: {mode} | Role: {role} | Room: {roomId}</p>
          <p>Status: {isConnected ? 'Connected' : 'Disconnected'}</p>
        </div>
      </header>
    </div>
  );
}

export default App;
