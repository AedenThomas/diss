import { io, Socket } from 'socket.io-client';

export type ArchitectureMode = 'P2P' | 'SFU';

export interface WebRTCConfig {
  mode: ArchitectureMode;
  signalingServerUrl: string;
  sfuServerUrl?: string;
  role: 'presenter' | 'viewer';
  roomId: string;
}

export class WebRTCService {
  private signalingSocket: Socket | null = null;
  private sfuSocket: Socket | null = null;
  private localStream: MediaStream | null = null;
  private peerConnections: Map<string, RTCPeerConnection> = new Map();
  private config: WebRTCConfig;
  private onRemoteStream?: (stream: MediaStream, peerId: string) => void;
  private onLocalStream?: (stream: MediaStream) => void;
  private onConnected?: () => void;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  
  // SFU specific properties
  private device: any = null;
  private producerTransport: any = null;
  private consumerTransport: any = null;
  private producer: any = null;
  private consumers: Map<string, any> = new Map();

  constructor(config: WebRTCConfig) {
    this.config = config;
    
    // Create canvas for timestamp embedding
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d')!;
  }

  setOnRemoteStreamCallback(callback: (stream: MediaStream, peerId: string) => void) {
    this.onRemoteStream = callback;
  }

  setOnLocalStreamCallback(callback: (stream: MediaStream) => void) {
    this.onLocalStream = callback;
  }

  setOnConnectedCallback(callback: () => void) {
    this.onConnected = callback;
  }

  async initialize(): Promise<void> {
    if (this.config.mode === 'P2P') {
      await this.initializeP2P();
    } else {
      await this.initializeSFU();
    }
  }

  private async initializeP2P(): Promise<void> {
    // Connect to signaling server
    this.signalingSocket = io(this.config.signalingServerUrl);
    
    // Add connection handler
    this.signalingSocket.on('connect', () => {
      console.log('Connected to signaling server');
      this.onConnected?.();
    });
    
    this.setupP2PSignalingHandlers();

    // Join room
    this.signalingSocket.emit('join-room', {
      roomId: this.config.roomId,
      role: this.config.role,
      mode: this.config.mode
    });

    // If presenter, start screen capture
    if (this.config.role === 'presenter') {
      await this.startScreenCapture();
    }
  }

  private async initializeSFU(): Promise<void> {
    // Connect to SFU server
    this.sfuSocket = io(this.config.sfuServerUrl!);
    
    // Add connection handler
    this.sfuSocket.on('connect', () => {
      console.log('Connected to SFU server');
      this.onConnected?.();
    });
    
    await this.setupSFUHandlers();

    // Join SFU room
    this.sfuSocket.emit('join-sfu-room', {
      roomId: this.config.roomId
    });

    // If presenter, start screen capture
    if (this.config.role === 'presenter') {
      await this.startScreenCapture();
    }
  }

  private setupP2PSignalingHandlers(): void {
    if (!this.signalingSocket) return;

    this.signalingSocket.on('peer-joined', (peerId: string) => {
      if (this.config.role === 'presenter') {
        this.createP2PPeerConnection(peerId, true);
      }
    });

    this.signalingSocket.on('offer', async ({ offer, from }: { offer: RTCSessionDescriptionInit, from: string }) => {
      const pc = this.createP2PPeerConnection(from, false);
      await pc.setRemoteDescription(offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      
      this.signalingSocket?.emit('answer', {
        answer,
        to: from,
        roomId: this.config.roomId
      });
    });

    this.signalingSocket.on('answer', async ({ answer, from }: { answer: RTCSessionDescriptionInit, from: string }) => {
      const pc = this.peerConnections.get(from);
      if (pc) {
        await pc.setRemoteDescription(answer);
      }
    });

    this.signalingSocket.on('ice-candidate', async ({ candidate, from }: { candidate: RTCIceCandidateInit, from: string }) => {
      const pc = this.peerConnections.get(from);
      if (pc) {
        await pc.addIceCandidate(candidate);
      }
    });

    this.signalingSocket.on('peer-left', (peerId: string) => {
      const pc = this.peerConnections.get(peerId);
      if (pc) {
        pc.close();
        this.peerConnections.delete(peerId);
      }
    });
  }

  private async setupSFUHandlers(): Promise<void> {
    if (!this.sfuSocket) return;

    return new Promise((resolve, reject) => {
      this.sfuSocket!.on('router-rtp-capabilities', async ({ rtpCapabilities }) => {
        try {
          // Load mediasoup-client device
          const mediasoupClient = await import('mediasoup-client');
          this.device = new mediasoupClient.Device();
          
          await this.device.load({ routerRtpCapabilities: rtpCapabilities });
          console.log('SFU device loaded');

          if (this.config.role === 'presenter') {
            await this.createSFUProducerTransport();
          } else {
            await this.createSFUConsumerTransport();
          }

          resolve();
        } catch (error) {
          console.error('Error setting up SFU:', error);
          reject(error);
        }
      });

      this.sfuSocket!.on('webrtc-transport-created', async ({ id, iceParameters, iceCandidates, dtlsParameters }) => {
        if (this.config.role === 'presenter' && !this.producerTransport) {
          const mediasoupClient = await import('mediasoup-client');
          this.producerTransport = this.device.createSendTransport({
            id,
            iceParameters,
            iceCandidates,
            dtlsParameters
          });

          this.producerTransport.on('connect', async ({ dtlsParameters }: any, callback: any, errback: any) => {
            try {
              this.sfuSocket?.emit('connect-webrtc-transport', {
                transportId: id,
                dtlsParameters
              });
              
              this.sfuSocket?.once('webrtc-transport-connected', () => {
                callback();
              });
            } catch (error) {
              errback(error);
            }
          });

          this.producerTransport.on('produce', async ({ kind, rtpParameters }: any, callback: any, errback: any) => {
            try {
              this.sfuSocket?.emit('produce', {
                transportId: id,
                kind,
                rtpParameters
              });

              this.sfuSocket?.once('produced', ({ id: producerId }: any) => {
                callback({ id: producerId });
              });
            } catch (error) {
              errback(error);
            }
          });

          // Start producing if we have a stream
          if (this.localStream) {
            await this.startSFUProducing();
          }

        } else if (this.config.role === 'viewer' && !this.consumerTransport) {
          const mediasoupClient = await import('mediasoup-client');
          this.consumerTransport = this.device.createRecvTransport({
            id,
            iceParameters,
            iceCandidates,
            dtlsParameters
          });

          this.consumerTransport.on('connect', async ({ dtlsParameters }: any, callback: any, errback: any) => {
            try {
              this.sfuSocket?.emit('connect-webrtc-transport', {
                transportId: id,
                dtlsParameters
              });
              
              this.sfuSocket?.once('webrtc-transport-connected', () => {
                callback();
              });
            } catch (error) {
              errback(error);
            }
          });
        }
      });

      this.sfuSocket!.on('new-producer', async ({ producerId }) => {
        if (this.config.role === 'viewer') {
          await this.startSFUConsuming(producerId);
        }
      });

      this.sfuSocket!.on('consumed', async ({ id, producerId, kind, rtpParameters }) => {
        if (this.consumerTransport) {
          const consumer = await this.consumerTransport.consume({
            id,
            producerId,
            kind,
            rtpParameters
          });

          this.consumers.set(id, consumer);
          
          // Resume consumer
          this.sfuSocket?.emit('resume-consumer', { consumerId: id });

          // Handle the stream
          const stream = new MediaStream([consumer.track]);
          this.onRemoteStream?.(stream, producerId);
        }
      });

      this.sfuSocket!.on('consumer-closed', ({ consumerId }) => {
        const consumer = this.consumers.get(consumerId);
        if (consumer) {
          consumer.close();
          this.consumers.delete(consumerId);
        }
      });

      this.sfuSocket!.on('error', (error) => {
        console.error('SFU socket error:', error);
        reject(error);
      });
    });
  }

  private async createSFUProducerTransport(): Promise<void> {
    this.sfuSocket?.emit('create-webrtc-transport', {
      producing: true,
      consuming: false,
      roomId: this.config.roomId
    });
  }

  private async createSFUConsumerTransport(): Promise<void> {
    this.sfuSocket?.emit('create-webrtc-transport', {
      producing: false,
      consuming: true,
      roomId: this.config.roomId
    });
  }

  private async startSFUProducing(): Promise<void> {
    if (!this.producerTransport || !this.localStream) return;

    try {
      const videoTrack = this.localStream.getVideoTracks()[0];
      if (videoTrack) {
        this.producer = await this.producerTransport.produce({
          track: videoTrack
        });

        console.log('SFU producer started:', this.producer.id);
      }
    } catch (error) {
      console.error('Error starting SFU producing:', error);
    }
  }

  private async startSFUConsuming(producerId: string): Promise<void> {
    if (!this.device || !this.consumerTransport) return;

    try {
      this.sfuSocket?.emit('consume', {
        producerId,
        rtpCapabilities: this.device.rtpCapabilities
      });
    } catch (error) {
      console.error('Error starting SFU consuming:', error);
    }
  }

  private createP2PPeerConnection(peerId: string, isInitiator: boolean): RTCPeerConnection {
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' }
      ]
    });

    this.peerConnections.set(peerId, pc);

    // Add local stream if available
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => {
        pc.addTrack(track, this.localStream!);
      });
    }

    // Handle remote stream
    pc.ontrack = (event) => {
      const remoteStream = event.streams[0];
      this.onRemoteStream?.(remoteStream, peerId);
    };

    // Handle ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.signalingSocket?.emit('ice-candidate', {
          candidate: event.candidate,
          to: peerId,
          roomId: this.config.roomId
        });
      }
    };

    // If initiator, create offer
    if (isInitiator) {
      this.createP2POffer(pc, peerId);
    }

    return pc;
  }

  private async createP2POffer(pc: RTCPeerConnection, peerId: string): Promise<void> {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    
    this.signalingSocket?.emit('offer', {
      offer,
      to: peerId,
      roomId: this.config.roomId
    });
  }

  private async startScreenCapture(): Promise<void> {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          // @ts-ignore - contentHint is not in TypeScript types yet
          contentHint: 'detail'
        },
        audio: false
      });

      // Embed timestamp in video stream
      this.localStream = this.addTimestampToStream(stream);
      this.onLocalStream?.(this.localStream);

      // Handle mode-specific logic
      if (this.config.mode === 'P2P') {
        // Add stream to existing peer connections
        this.peerConnections.forEach(pc => {
          this.localStream!.getTracks().forEach(track => {
            pc.addTrack(track, this.localStream!);
          });
        });
      } else if (this.config.mode === 'SFU' && this.producerTransport) {
        // Start SFU producing
        await this.startSFUProducing();
      }

    } catch (error) {
      console.error('Error starting screen capture:', error);
      throw error;
    }
  }

  private addTimestampToStream(originalStream: MediaStream): MediaStream {
    const video = document.createElement('video');
    video.srcObject = originalStream;
    video.play();

    this.canvas.width = 1920; // Assuming 1080p
    this.canvas.height = 1080;

    const canvasStream = this.canvas.captureStream(30); // 30 FPS

    const drawFrame = () => {
      if (video.videoWidth > 0 && video.videoHeight > 0) {
        // Draw original video
        this.ctx.drawImage(video, 0, 0, this.canvas.width, this.canvas.height);
        
        // Embed timestamp in top-left pixel
        const timestamp = Date.now();
        const imageData = this.ctx.getImageData(0, 0, 1, 1);
        
        // Encode timestamp in RGB values (simplified approach)
        const r = (timestamp >>> 16) & 0xFF;
        const g = (timestamp >>> 8) & 0xFF;
        const b = timestamp & 0xFF;
        
        imageData.data[0] = r;
        imageData.data[1] = g;
        imageData.data[2] = b;
        imageData.data[3] = 255; // Alpha
        
        this.ctx.putImageData(imageData, 0, 0);
      }
      
      requestAnimationFrame(drawFrame);
    };

    video.onloadedmetadata = () => {
      drawFrame();
    };

    return canvasStream;
  }

  // Extract timestamp from received video stream
  extractTimestamp(videoElement: HTMLVideoElement): number | null {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;
      
      ctx.drawImage(videoElement, 0, 0);
      const imageData = ctx.getImageData(0, 0, 1, 1);
      
      const r = imageData.data[0];
      const g = imageData.data[1];
      const b = imageData.data[2];
      
      // Decode timestamp from RGB values
      const timestamp = (r << 16) | (g << 8) | b;
      return timestamp;
    } catch (error) {
      console.error('Error extracting timestamp:', error);
      return null;
    }
  }

  async disconnect(): Promise<void> {
    // Stop local stream
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
    }

    // Close P2P peer connections
    this.peerConnections.forEach(pc => pc.close());
    this.peerConnections.clear();

    // Close SFU resources
    if (this.producer) {
      this.producer.close();
    }

    this.consumers.forEach(consumer => consumer.close());
    this.consumers.clear();

    if (this.producerTransport) {
      this.producerTransport.close();
    }

    if (this.consumerTransport) {
      this.consumerTransport.close();
    }

    // Disconnect from servers
    if (this.signalingSocket) {
      this.signalingSocket.disconnect();
    }

    if (this.sfuSocket) {
      this.sfuSocket.disconnect();
    }
  }
}